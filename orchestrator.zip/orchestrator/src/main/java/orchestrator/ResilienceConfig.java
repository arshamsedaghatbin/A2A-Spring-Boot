package orchestrator;


import org.springframework.context.annotation.Configuration;

@Configuration
public class ResilienceConfig {
}
