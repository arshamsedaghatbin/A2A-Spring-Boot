package orchestrator;

import com.google.adk.a2a.agent.RemoteA2AAgent;
import com.google.adk.agents.BaseAgent;
import com.google.adk.agents.LlmAgent;
import com.google.adk.web.AgentLoader;
import com.google.adk.web.AgentStaticLoader;
import io.a2a.client.Client;
import io.a2a.client.http.JdkA2AHttpClient;
import io.a2a.client.transport.jsonrpc.JSONRPCTransport;
import io.a2a.client.transport.jsonrpc.JSONRPCTransportConfigBuilder;
import io.a2a.spec.AgentCapabilities;
import io.a2a.spec.AgentCard;
import io.a2a.spec.AgentSkill;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Bank Orchestrator (port 8080)
 * هماهنگ‌کننده اصلی — از طریق A2A با ۳ agent دیگر ارتباط می‌گیره:
 *   auth-agent    → port 8081
 *   balance-agent → port 8082
 *   transfer-agent → port 8083
 *
 * Flow: auth-agent → balance-agent → transfer-agent (delegated via RemoteA2AAgent subAgents)
 */
@Configuration(proxyBeanMethods = false)
@ComponentScan(basePackages = "orchestrator")
public class Agent {

  private static final Logger log = LoggerFactory.getLogger(Agent.class);

  private static final String AUTH_BASE_URL     = "http://localhost:8081";
  private static final String BALANCE_BASE_URL  = "http://localhost:8082";
  private static final String TRANSFER_BASE_URL = "http://localhost:8083";

  /**
   * Builds a RemoteA2AAgent from a locally-constructed AgentCard — no network call at startup.
   * The card URL is the only thing the A2A client needs to route messages; skills are discovered
   * at runtime so an empty list is fine here.
   */
  private static RemoteA2AAgent createRemoteAgent(String name, String description, String baseUrl) {
    AgentCard card = new AgentCard.Builder()
        .name(name)
        .description(description)
        .url(baseUrl + "/a2a/remote/v1/message:send")
        .version("1.0.0")
        .capabilities(new AgentCapabilities.Builder().streaming(false).build())
        .defaultInputModes(List.of("text/plain"))
        .defaultOutputModes(List.of("text/plain"))
        .skills(List.of())
        .build();
    JdkA2AHttpClient httpClient = new JdkA2AHttpClient();
    Client client = Client.builder(card)
        .withTransport(JSONRPCTransport.class,
            new JSONRPCTransportConfigBuilder().httpClient(httpClient).build())
        .build();
    return RemoteA2AAgent.builder()
        .name(card.name())
        .agentCard(card)
        .a2aClient(client)
        .build();
  }

  @Bean
  @Lazy
  public LlmAgent rootLlmAgent() {
    RemoteA2AAgent authAgent     = createRemoteAgent("auth-agent",     "Authenticates the user",              AUTH_BASE_URL);
    RemoteA2AAgent balanceAgent  = createRemoteAgent("balance-agent",  "Checks account balance",              BALANCE_BASE_URL);
    RemoteA2AAgent transferAgent = createRemoteAgent("transfer-agent", "Executes money transfers",            TRANSFER_BASE_URL);

    return LlmAgent.builder()
        .name("bank-orchestrator")
        .model("gemini-2.5-flash")
        .description("Orchestrates bank transfer: auth → balance check → transfer.")
        .instruction(
            "You are a bank transfer orchestrator. Follow these steps IN ORDER:\n"
            + "1. Delegate to auth-agent — authenticate the user\n"
            + "2. Delegate to balance-agent — check the source account has sufficient funds\n"
            + "3. Delegate to transfer-agent — perform the transfer\n\n"
            + "Stop and explain if any step fails. "
            + "Ask for userId, fromAccount, toAccount, amount (IRR) if not provided.")
        .subAgents(authAgent, balanceAgent, transferAgent)
        .build();
  }

  @Bean
  @Lazy
  public BaseAgent rootAgent(LlmAgent rootLlmAgent) { return rootLlmAgent; }

  @Bean
  @Lazy
  public AgentLoader agentLoader(LlmAgent rootLlmAgent) { return new AgentStaticLoader(rootLlmAgent); }

  @RestController
  public static class AgentCardController {
    @Value("${app.url}") private String appUrl;
    @Value("${agent.name:bank-orchestrator}") private String agentName;
    @Value("${agent.description:Orchestrates bank transfer: auth → balance check → transfer.}") private String agentDescription;

    @GetMapping("/.well-known/agent-card.json")
    public AgentCard getAgentCard() {
      List<AgentSkill> skills = List.of(
          new AgentSkill.Builder()
              .id("bank-orchestrator-transfer")
              .name("bank-transfer")
              .description("Orchestrates full bank transfer flow: auth → balance check → transfer")
              .tags(List.of("orchestrator", "banking"))
              .build()
      );
      return new AgentCard.Builder()
          .name(agentName)
          .description(agentDescription)
          .url(appUrl + "/a2a/remote/v1/message:send")
          .version("1.1.0")
          .capabilities(new AgentCapabilities.Builder().streaming(false).build())
          .defaultInputModes(List.of("text/plain"))
          .defaultOutputModes(List.of("text/plain"))
          .skills(skills)
          .build();
    }
  }
}
